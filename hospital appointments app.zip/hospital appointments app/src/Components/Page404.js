import React from 'react'

export const Page404 = () => {
  return (
    <div>
      <h1>404 Error</h1>
      <p>page not found</p>
    </div>
  )
}
