export const menus = [
  {
    id: '1',
    name: 'Task List',
    path: '/',
    cName: 'menu-links',
  },
  {
    id: '2',
    name: 'Send Request',
    path: '/SendRequest',
    cName: 'menu-links',
  },
  {
    id: '3',
    name: 'Document Status',
    path: '/DocumentStatus',
    cName: 'menu-links',
  },
  {
    id: '4',
    name: 'Fax',
    path: '/Fax',
    cName: 'menu-links',
  },
  {
    id: '5',
    name: 'Account',
    path: '/Account',
    cName: 'menu-links',
  },
]
