import React, { Component } from 'react'

export default class SendRequest extends Component {
  render() {
    return (
      <div
        style={{
          textAlign: 'center',
        }}
      >
        <h4>send request 404 error</h4>
      </div>
    )
  }
}
