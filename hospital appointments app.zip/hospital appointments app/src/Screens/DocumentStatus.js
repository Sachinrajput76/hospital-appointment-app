import React, { Component } from 'react'

export default class DocumentStatus extends Component {
  render() {
    return (
      <div
        style={{
          textAlign: 'center',
        }}
      >
        <h4>Document Status 404 error</h4>
      </div>
    )
  }
}
