import React, { Component } from 'react'

export default class Fax extends Component {
  render() {
    return (
      <div
        style={{
          textAlign: 'center',
        }}
      >
        <h4>Fax 404 error</h4>
      </div>
    )
  }
}
