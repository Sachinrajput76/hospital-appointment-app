import React, { Component } from 'react'

export default class Account extends Component {
  render() {
    return (
      <div
        style={{
          textAlign: 'center',
        }}
      >
        <h4>Account 404 error</h4>
      </div>
    )
  }
}
